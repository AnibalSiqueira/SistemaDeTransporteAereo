delimiter //
	CREATE DEFINER=`sistemaAereo`@`localhost` PROCEDURE `proc_apagaManutencao`(
	IN `codApagar` INT
)
LANGUAGE SQL
NOT DETERMINISTIC
CONTAINS SQL
SQL SECURITY DEFINER
COMMENT ''
BEGIN

	SELECT COUNT(*) INTO @contador FROM tb_manutencao WHERE id_manutencao = codApagar;
	if (@contador = 1)
		then 
			DELETE FROM tb_manutencao WHERE id_manutencao = codApagar;
			SELECT "Manutenção apagado com sucesso" AS mensagem;
		ELSE SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = "Manutenção inexistente"; 
	END if;
	SELECT * FROM tb_manutencao;

END //

delimiter ;