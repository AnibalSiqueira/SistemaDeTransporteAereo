delimiter //

CREATE DEFINER=`sistemaAereo`@`localhost` PROCEDURE `proc_alteraTripulacao`(
	IN `codAlterar` INT,
	IN `alteraTipoTripulante` VARCHAR(45),
	IN `alteraLicenca` VARCHAR(45),
	IN `alteraValidade_licenca` DATE,
	IN `alteraHoras_voadas` DOUBLE,
	IN `alteraCertificacoes` VARCHAR(45)
)
LANGUAGE SQL
NOT DETERMINISTIC
CONTAINS SQL
SQL SECURITY DEFINER
COMMENT ''
BEGIN
	SELECT COUNT(*) 
	INTO @existe FROM tb_tripulacao WHERE id_tripulacao = codAlterar;
	if (@existe)
		then UPDATE tb_tripulacao SET tipoTripulante = alteraTipoTripulante, licenca = alteraLicenca, validade_licenca = alteraValidade_licenca, horas_voadas = alteraHoras_voadas,
		 certificacoes = alteraCertificacoes
		 WHERE id_tripulacao = codAlterar;
		ELSE SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = "Tripulação inexistente"; 
	END if;
	
	SELECT * FROM tb_tripulacao;
END //

delimiter ;
