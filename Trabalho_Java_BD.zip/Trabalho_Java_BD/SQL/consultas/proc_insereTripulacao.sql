delimiter //

CREATE DEFINER=`sistemaAereo`@`localhost` PROCEDURE `proc_insereTripulacao`(
	IN `insTipoTripulante` VARCHAR(45),
	IN `insLicenca` VARCHAR(45),
	IN `insValidade_licenca` DATE,
	IN `insHoras_voadas` DOUBLE,
	IN `insCertificacoes` VARCHAR(45)
)
LANGUAGE SQL
NOT DETERMINISTIC
CONTAINS SQL
SQL SECURITY DEFINER
COMMENT ''
BEGIN

	INSERT INTO tb_tripulacao 
	VALUES(
		NULL, 
		insTipoTripulante, 
		insLicenca, 
		insValidade_licenca,
		insHoras_voadas, 
		insCertificacoes 
	);
	
	SELECT * FROM tb_tripulacao;
END //

delimiter ;
