delimiter //

CREATE DEFINER=`sistemaAereo`@`localhost` PROCEDURE `proc_insereVoos`(
	IN `insNumVoo` VARCHAR(45),
	IN `insStatusVoo` VARCHAR(45),
	IN `insTB_avioes_id` INT,
	IN `insTB_aeroportos_id` INT
)
LANGUAGE SQL
NOT DETERMINISTIC
CONTAINS SQL
SQL SECURITY DEFINER
COMMENT ''
BEGIN
	INSERT INTO tb_voos 
	VALUES(
		NULL, 
		insNumVoo, 
		insStatusVoo, 
		insTB_avioes_id, 
		insTB_aeroportos_id
	);
	SELECT * FROM tb_voos;
END //

delimiter ;
