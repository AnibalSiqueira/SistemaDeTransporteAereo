delimiter //

CREATE DEFINER=`sistemaAereo`@`localhost` PROCEDURE `proc_alteraPassagem`(
	IN `codAlterar` INT,
	IN `alteraNumeroPassagem` VARCHAR(45),
	IN `alteraClassePassagem` VARCHAR(45),
	IN `alteraDataDeVoo` DATE,
	IN `alteraDestinoPassagem` VARCHAR(45),
	IN `alteraPrecoPassagem` DOUBLE,
	IN `alteraAssentoPassagem` VARCHAR(10),
	IN `alteraTB_voos_id` INT,
	IN `alteraTB_passageiro_id` INT,
	IN `alteraTB_pagamento_id` INT
)
LANGUAGE SQL
NOT DETERMINISTIC
CONTAINS SQL
SQL SECURITY DEFINER
COMMENT ''
BEGIN
	SELECT COUNT(*) 
	INTO @existe FROM tb_passagem WHERE id_passagem = codAlterar;
	if (@existe)
		then UPDATE tb_passagem SET numeroPassagem = alteraNumeroPassagem, classePassagem = alteraClassePassagem, dataDeVoo = alteraDataDeVoo, destinoPassagem = alteraDestinoPassagem,
		 precoPassagem = alteraPrecoPassagem, assentoPassagem = alteraAssentoPassagem, tb_voos_id = alteraTB_voos_id, tb_passageiro_id = alteraTB_passageiro_id, tb_pagamento_id = alteraTB_pagamento_id
		 WHERE codCliente = codAlterar;
		ELSE SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = "Passagem inexistente"; 
	END if;
	
	SELECT * FROM tb_passagem;

END //

delimiter ;