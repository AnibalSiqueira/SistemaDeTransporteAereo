delimiter //
CREATE DEFINER=`sistemaAereo`@`localhost` PROCEDURE `proc_apagaTripulacao`(
	IN `codApagar` INT
)
LANGUAGE SQL
NOT DETERMINISTIC
CONTAINS SQL
SQL SECURITY DEFINER
COMMENT ''
BEGIN
SELECT COUNT(*) INTO @contador FROM tb_tripulacao WHERE id_tripulacao = codApagar;
	if (@contador = 1)
		then 
			DELETE FROM tb_tripulacao WHERE id_tripulacao = codApagar;
			SELECT "Tripulação apagada com sucesso" AS mensagem;
		ELSE SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = "Tripulação inexistente"; 
	END if;
	SELECT * FROM tb_tripulacao;

END //

delimiter ;