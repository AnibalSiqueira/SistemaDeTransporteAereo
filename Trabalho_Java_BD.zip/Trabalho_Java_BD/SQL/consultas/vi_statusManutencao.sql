create view vi_statusManutencao AS(
SELECT a.modelo,
       f.nomeFabricante AS fabricante,
       DATE_FORMAT(m.data_inicio, '%d/%m/%Y') AS data_inicioManutencao,
       DATE_FORMAT(m.data_fim, '%d/%m/%Y') AS data_fimManutencao,
       m.tipoManutencao,
       m.descricao,
       m.statos
FROM tb_avioes AS a
INNER JOIN tb_fabricante AS f ON a.tb_montadoras_id = f.id_fabricante
INNER JOIN tb_manutencao AS m ON a.id_aviao = m.tb_avioes_id
ORDER BY a.modelo ASC);