delimiter //

CREATE DEFINER=`sistemaAereo`@`localhost` PROCEDURE `proc_alteraVoos`(
	IN `codAlterar` INT,
	IN `alteraNumVoo` VARCHAR(45),
	IN `alteraStatusVoo` VARCHAR(45),
	IN `alteraTB_avioes_id` INT,
	IN `alteraTB_aeroportos_id` INT
)
LANGUAGE SQL
NOT DETERMINISTIC
CONTAINS SQL
SQL SECURITY DEFINER
COMMENT ''
BEGIN
	SELECT COUNT(*) 
	INTO @existe FROM tb_voos WHERE id_voo = codAlterar;
	if (@existe)
		then UPDATE tb_voos SET numVoo = alteraNumVoo, statusVoo = alteraStatusVoo, tb_avioes_id = alteraTB_avioes_id, tb_aeroportos_id = alteraTB_aeroportos_id
		 WHERE id_voos = codAlterar;
		ELSE SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = "Voo inexistente"; 
	END if;
	
	SELECT * FROM tb_voos;
END //

delimiter ;