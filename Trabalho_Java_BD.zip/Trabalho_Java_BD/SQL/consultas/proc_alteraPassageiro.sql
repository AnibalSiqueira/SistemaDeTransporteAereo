delimiter //

CREATE DEFINER=`sistemaAereo`@`localhost` PROCEDURE `proc_alteraPassageiro`(
	IN `nomeNovo` VARCHAR(50),
	IN `emailNovo` VARCHAR(50),
	IN `telefoneNovo` VARCHAR(50),
	IN `codAlterar` INT
)
LANGUAGE SQL
NOT DETERMINISTIC
CONTAINS SQL
SQL SECURITY DEFINER
COMMENT ''
BEGIN


 	SELECT COUNT(*) 
	INTO @existe FROM tb_passageiro WHERE id_passageiro = codAlterar;
	if (@existe)
		then UPDATE tb_passageiro SET  nomePassageiro=nomeNovo, emailPassageiro=emailNovo, telefonePassageiro=telefoneNovo
		
		 WHERE id_passageiro = codAlterar;
		 
		ELSE SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = "Passageiro inexistente"; 
	END if;
	
	SELECT * FROM tb_passageiro;

END //

delimiter ;