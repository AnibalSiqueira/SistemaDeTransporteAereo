delimiter //
CREATE DEFINER=`sistemaAereo`@`localhost` PROCEDURE `proc_insereFuncionario`(
	IN `insNomeFuncionario` VARCHAR(50),
	IN `insCPF` VARCHAR(50),
	IN `insCargo` VARCHAR(50),
	IN `insEmail` VARCHAR(50),
	IN `insTelefoneFuncionario` VARCHAR(50),
	IN `insStatus` VARCHAR(50),
	IN `insSalario` DOUBLE,
	IN `insTB_companhiaAerea_id` INT
)
LANGUAGE SQL
NOT DETERMINISTIC
CONTAINS SQL
SQL SECURITY DEFINER
COMMENT ''
BEGIN

	INSERT INTO tb_funcionarios(
		nomeFuncionario, 
		cpfFuncionario, 
		cargoFuncionario, 
		emailFuncionario,
		telefoneFuncionario, 
		statusFuncionario, 
		salarioFuncionario, 
		tb_companhiaAerea_id
	) 
	VALUES(
		insNomeFuncionario, 
		insCPF, 
		insCargo, 
		insEmail, 
		insTelefoneFuncionario, 
		insStatus, 
		insSalario, 
		insTB_companhiaAerea_id
	);
	SELECT * FROM tb_funcionarios;

END //

delimiter;