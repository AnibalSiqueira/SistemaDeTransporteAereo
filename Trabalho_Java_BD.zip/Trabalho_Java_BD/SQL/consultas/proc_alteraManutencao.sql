delimiter //

CREATE DEFINER=`sistemaAereo`@`localhost` PROCEDURE `proc_alteraManutencao`(
	IN `manutencaoAlterar` VARCHAR(150),
	IN `descricaoAlterar` VARCHAR(150),
	IN `data_inicioAlterar` DATE,
	IN `data_fimAlterar` DATE,
	IN `custoAlterar` DOUBLE,
	IN `statos_Alterar` VARCHAR(50),
	IN `tb_avioes_idAlterar` INT,
	IN `codAlterar` INT
)
LANGUAGE SQL
NOT DETERMINISTIC
CONTAINS SQL
SQL SECURITY DEFINER
COMMENT ''
BEGIN

 	SELECT COUNT(*) 
	INTO @existe FROM tb_manutencao WHERE id_manutencao = codAlterar;
	if (@existe)
		then UPDATE tb_manutencao SET tipoManutencao=manutencaoAlterar, descricao=descricaoAlterar, data_inicio=data_inicioAlterar,
		 data_fim=data_fimAlterar, custo=custoAlterar, statos=statos_Alterar, tb_avioes_id=tb_avioes_idAlterar
		 WHERE id_manutencao = codAlterar;
		ELSE SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = "Manutenção inexistente"; 
	END if;
	
	SELECT * FROM tb_manutencao;


END //

delimiter ;