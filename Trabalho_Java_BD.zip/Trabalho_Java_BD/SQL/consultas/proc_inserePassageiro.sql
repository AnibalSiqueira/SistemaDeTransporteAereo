delimiter //

CREATE DEFINER=`sistemaAereo`@`localhost` PROCEDURE `proc_inserePassageiro`(
	IN `insNome` VARCHAR(150),
	IN `insEmail` VARCHAR(50),
	IN `insTelefonePassageiro` VARCHAR(50)
)
LANGUAGE SQL
NOT DETERMINISTIC
CONTAINS SQL
SQL SECURITY DEFINER
COMMENT ''
BEGIN

 	INSERT INTO tb_passageiro(
		nomePassageiro, 
		emailPassageiro, 
		telefonePassageiro
	) 
	VALUES(
		insNome, 
		insEmail, 
		insTelefonePassageiro
	);
	SELECT * FROM tb_passageiro;

END //

delimiter ;
