CREATE VIEW vi_dadosPassagem AS(
SELECT
	TBpessoa.nomePassageiro,
	TBpass.precoPassagem,
	TBpass.destinoPassagem,
	TBpass.dataDeVoo,
	TBpass.assentoPassagem,
	TBaviao.modelo,
	TBaeroporto.codigo_icao,
	TBvoo.numVoo
FROM tb_passagem AS TBpass
INNER JOIN tb_voos AS TBvoo ON TBvoo.id_voo = TBpass.tb_voos_id
INNER JOIN tb_avioes AS TBaviao ON TBaviao.id_aviao = TBvoo.tb_avioes_id
INNER JOIN tb_aeroportos AS TBaeroporto ON TBaeroporto.id_aeroporto = TBvoo.tb_aeroportos_id
INNER JOIN tb_passageiro AS TBpessoa ON TBpessoa.id_passageiro = TBpass.tb_passageiro_id
ORDER BY TBpass.id_passagem ASC);