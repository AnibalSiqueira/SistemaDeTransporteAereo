delimiter //

CREATE DEFINER=`sistemaAereo`@`localhost` PROCEDURE `proc_apagaFuncionario`(
	IN `codApagar` INT
)
LANGUAGE SQL
NOT DETERMINISTIC
CONTAINS SQL
SQL SECURITY DEFINER
COMMENT ''
BEGIN

	SELECT COUNT(*) INTO @contador FROM tb_funcionarios WHERE id_funcionarios = codApagar;
	if (@contador = 1)
		then 
			DELETE FROM tb_funcionarios WHERE id_funcionarios = codApagar;
			SELECT "funcionario apagado com sucesso" AS mensagem;
		ELSE SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = "Passageiro inexistente"; 
	END if;
	SELECT * FROM tb_funcionarios;
	
END //

delimiter ;