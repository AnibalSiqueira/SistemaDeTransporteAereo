CREATE VIEW vi_dadosCompanhia AS(
SELECT 
	TBcomp.nomeCompanhia AS "Nome da companhia", 
	TBcomp.cnpj AS "CNPJ da companhia",
	TBcomp.statos AS "Status de funcionamento", 
	TBfab.nomeFabricante AS "Fabricante", 
	TBav.modelo AS "Modelo do avião"  
FROM tb_companhiaaerea AS TBcomp
INNER JOIN tb_avioes AS TBav ON TBav.tb_companhiaAerea_id = TBcomp.id_companhiaAerea
INNER JOIN tb_fabricante AS TBfab ON TBav.tb_companhiaAerea_id = TBfab.id_fabricante);