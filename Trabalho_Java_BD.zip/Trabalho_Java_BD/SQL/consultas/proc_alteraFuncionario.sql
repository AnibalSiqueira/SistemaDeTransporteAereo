delimiter //

CREATE DEFINER=`sistemaAereo`@`localhost` PROCEDURE `proc_alteraFuncionario`(
	IN `codAlterar` INT,
	IN `nomeAlterar` VARCHAR(50),
	IN `cpfAlterar` VARCHAR(50),
	IN `salarioAlterar` DOUBLE,
	IN `cargoAlterar` VARCHAR(50),
	IN `emailAlterar` VARCHAR(50),
	IN `telefoneAlterar` VARCHAR(50),
	IN `statosAlterar` VARCHAR(50),
	IN `companhiaAlterar` INT
)
LANGUAGE SQL
NOT DETERMINISTIC
CONTAINS SQL
SQL SECURITY DEFINER
COMMENT ''
BEGIN

	SELECT COUNT(*) 
	INTO @existe FROM tb_funcionarios WHERE id_funcionarios = codAlterar;
	if (@existe)
		then UPDATE tb_funcionarios SET nomeFuncionario = nomeAlterar, cpfFuncionario = cpfAlterar,
		 cargoFuncionario = cargoAlterar, emailFuncionario=emailAlterar, telefoneFuncionario=telefoneAlterar, statusFuncionario=statosAlterar, 
		 salarioFuncionario=salarioAlterar, tb_companhiaAerea_id=companhiaAlterar
		 WHERE codCliente = codAlterar;
		ELSE SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = "Funcionario inexistente"; 
	END if;
	
	SELECT * FROM tb_funcionarios;

END //

delimiter ;