delimiter //
CREATE DEFINER=`sistemaAereo`@`localhost` PROCEDURE `proc_apagaPassagem`(
	IN `codApagar` INT
)
LANGUAGE SQL
NOT DETERMINISTIC
CONTAINS SQL
SQL SECURITY DEFINER
COMMENT ''
BEGIN
SELECT COUNT(*) INTO @contador FROM tb_passagem WHERE id_passagem = codApagar;
	if (@contador = 1)
		then 
			DELETE FROM tb_passagem WHERE id_passagem = codApagar;
			SELECT "Passagem apagada com sucesso" AS mensagem;
		ELSE SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = "Passagem inexistente"; 
	END if;
	SELECT * FROM tb_passagem;

END //

delimiter ;