delimiter //

CREATE DEFINER=`sistemaAereo`@`localhost` PROCEDURE `proc_inserePassagem`(
	IN `insNumeroPassagem` VARCHAR(45),
	IN `insClassePassagem` VARCHAR(45),
	IN `insDataDeVoo` DATE,
	IN `insDestinoPassagem` VARCHAR(45),
	IN `insPrecoPassagem` DOUBLE,
	IN `insAssentoPassagem` VARCHAR(10),
	IN `insTB_voos_id` INT,
	IN `insTB_passageiro_id` INT,
	IN `insTB_pagamento_id` INT
)
LANGUAGE SQL
NOT DETERMINISTIC
CONTAINS SQL
SQL SECURITY DEFINER
COMMENT ''
BEGIN

	INSERT INTO tb_passagem 
	VALUES(
		NULL, 
		insNumeroPassagem, 
		insClassePassagem, 
		insDataDeVoo, 
		insDestinoPassagem, 
		insPrecoPassagem,
		insAssentoPassagem, 
		insTB_voos_id, 
		insTB_passageiro_id, 
		insTB_pagamento_id
	);
	
	SELECT * FROM tb_passagem;
END //

delimiter ;
