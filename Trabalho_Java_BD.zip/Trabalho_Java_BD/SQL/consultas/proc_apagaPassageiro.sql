delimiter //

CREATE DEFINER=`sistemaAereo`@`localhost` PROCEDURE `proc_apagaPassageiro`(
	IN `codApagar` INT
)
LANGUAGE SQL
NOT DETERMINISTIC
CONTAINS SQL
SQL SECURITY DEFINER
COMMENT ''
BEGIN

	SELECT COUNT(*) INTO @contador FROM tb_passageiro WHERE id_passageiro = codApagar;
	if (@contador = 1)
		then 
			DELETE FROM tb_passageiro WHERE id_passageiro = codApagar;
			SELECT "Passageiro apagado com sucesso" AS mensagem;
		ELSE SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = "Passageiro inexistente"; 
	END if;
	SELECT * FROM tb_passageiro;
	
END //

delimiter ;