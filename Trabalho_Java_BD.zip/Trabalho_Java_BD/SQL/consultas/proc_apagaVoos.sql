delimiter //
CREATE DEFINER=`sistemaAereo`@`localhost` PROCEDURE `proc_apagaVoos`(
	IN `codApagar` INT
)
LANGUAGE SQL
NOT DETERMINISTIC
CONTAINS SQL
SQL SECURITY DEFINER
COMMENT ''
BEGIN
SELECT COUNT(*) INTO @contador FROM tb_voos WHERE id_voo = codApagar;
	if (@contador = 1)
		then 
			DELETE FROM tb_passagem WHERE id_voo = codApagar;
			SELECT "Voo apagado com sucesso" AS mensagem;
		ELSE SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = "Voo inexistente"; 
	END if;
	SELECT * FROM tb_voos;

END //

delimiter ;