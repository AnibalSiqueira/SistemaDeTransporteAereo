CREATE VIEW vi_apresentacaoEmbarque AS(
SELECT
	TBpessoa.nomePassageiro AS "Passageiro que embarcou",
	TBcheck.data_checkIn AS "Data do check in",
	TBcheck.statos AS "Status atual do check in",
	TBcheck.portaoEmbarque AS "Portão à embarcar",
	TBpass.classePassagem AS "Classe de embarque"
FROM tb_checkin AS TBcheck
INNER JOIN tb_passagem AS TBpass ON TBpass.id_passagem = TBcheck.tb_passagem_id
INNER JOIN tb_passageiro AS TBpessoa ON TBpessoa.id_passageiro = TBpass.tb_passageiro_id);