delimiter //

CREATE DEFINER=`sistemaAereo`@`localhost` PROCEDURE `proc_insereManutencao`(
	IN `insTipo` VARCHAR(150),
	IN `insDataInicio` DATE,
	IN `insDataFim` DATE,
	IN `insDescricao` MEDIUMTEXT,
	IN `insCusto` DOUBLE,
	IN `insStatus` VARCHAR(50),
	IN `insTB_avioes_id` INT
)
LANGUAGE SQL
NOT DETERMINISTIC
CONTAINS SQL
SQL SECURITY DEFINER
COMMENT ''
BEGIN



	INSERT INTO tb_manutencao(
		tipoManutencao, 
		descricao, 
		data_inicio, 
		data_fim, 
		custo, 
		statos, 
		tb_avioes_id
	) 
	VALUES(
		insTipo,
		insDataInicio,
		insDataFim,
		insDescricao,
		insCusto,
		insStatus,
		insTB_avioes_id
	);
	SELECT * FROM tb_manutencao;


END //

delimiter ;