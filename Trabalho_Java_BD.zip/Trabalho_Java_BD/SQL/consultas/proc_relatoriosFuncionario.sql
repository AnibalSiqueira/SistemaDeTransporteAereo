delimiter //
CREATE DEFINER=`sistemaAereo`@`localhost` PROCEDURE `proc_relatoriosFuncionario`(
	IN `tipoRelatorio` INT,
	IN `nomeBusca` VARCHAR(100)
)
LANGUAGE SQL
NOT DETERMINISTIC
CONTAINS SQL
SQL SECURITY DEFINER
COMMENT ''
BEGIN

					if (tipoRelatorio = '1' )
					then SELECT fu.nomeFuncionario, fu.emailFuncionario, fu.telefoneFuncionario FROM tb_funcionarios AS fu ORDER BY fu.nomeFuncionario ASC;
					
					ELSE if (tipoRelatorio = '2' )
					then SELECT fu.nomeFuncionario, fu.cpfFuncionario, fu.cargoFuncionario, fu.statusFuncionario, 
					fu.tb_companhiaAerea_id FROM tb_funcionarios AS fu ORDER BY fu.nomeFuncionario ASC;
					
					ELSE if (tipoRelatorio = '3' )
					then SELECT * FROM tb_funcionarios AS f WHERE nomeFuncionario LIKE CONCAT('%', nomeBusca, '%') ;
					
					ELSE SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = "Relatório inexistente"; 
					END if;
					END if;
					END if;
				
END //

delimiter ;